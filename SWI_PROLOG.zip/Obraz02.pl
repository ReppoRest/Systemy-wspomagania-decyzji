woman(left).
woman(middle).
woman(right).

items(bag).
items(purse).
items(ankleBracelet).

wearsShortDress(left;right).
wearsLongDress(middle).

ownsItem(left, ankleBracelet).
ownsItem(middle, purse).
ownsItem(right, phone).





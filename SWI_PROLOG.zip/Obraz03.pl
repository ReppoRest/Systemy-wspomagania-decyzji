character(jon).
character(eddard).
character(olenna).
character(tywin).
character(cersei).
character(arya).
character(jaime).
character(daenerys).


familyties(jaime):- character(cersei),character(tywin).
familyties(cersei):- character(tywin),character(jaime).
familyties(tywin):- character(jaime),character(cersei).


familyties(eddard):- character(arya),character(jon).
familyties(arya):- character(jon),character(eddard).
familyties(jon):- character(eddard),character(arya).

familyties(eddard, arya).
familyties(eddard, jon).
familyties(arya, eddard).
familyties(arya, jon).
familyties(jon, arya).
familyties(jon, eddard).

familyties(tywin, cersei).
familyties(tywin, jaime).
familyties(jaime, cersei).
familyties(jaime, tywin).
familyties(cersei, tywin).
familyties(cersei, jaime).
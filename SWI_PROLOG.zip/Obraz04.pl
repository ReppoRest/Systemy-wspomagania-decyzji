character(Szarik).
character(Gustlik).
character(Janek).
character(Olgierd).
character(Grigorij).

task(loader).
task(shooter).
task(commander).
task(driver).

human(Gustlik; Janek; Olgierd; Grigorij).
dog(Szarik).

ownsSzarik(Janek)

taskAssignment(Gustlik, loader).
taskAssignment(Janek, shooter).
taskAssignment(Olgierd, commander).
taskAssignment(Grigorij, driver).
